import gymnasium as gym
from stable_baselines3 import DQN
import sys
import highway_env
import matplotlib.pyplot as plt
import os
import time
import pandas as pd


version = "test"
log_path = "F:\\RMRL_Project\\RMRL1\\date\\highway\\sb3_dqn\\highway_sb3_dqn\\"
model_path = log_path + "model_" + str(version)
model_name = model_path + ".zip"

if not os.path.isdir(log_path):
    os.makedirs(log_path)

if __name__ == '__main__':
    env = gym.make('highway-v0')
    # Train = False
    Train = True

    # save_picture_sig = False   # whether save collision picture
    save_picture_sig = True

    config = {
        "observation": {
            "type": "Kinematics",
            "features": ["x", "y", "vx", "vy", "heading"],
            "features_range": {
                "x": [-100, 100],
                "y": [-6, 6],
                "vx": [-30, 30],
                "vy": [-30, 30],
                "heading": [-3.15 / 2, 3.15 / 2]
                },
            "absolute": False,
            "normalize": True,
            "see_behind": False,
            "order": "sorted",
        },
        "action": {
            "type": "DiscreteMetaAction",
        },
        "lanes_count": 2,
        "vehicles_count": 10,
        "policy_frequency": 8,
        "simulation_frequency": 8,

        "use_rm_obs": True,  # if True use rm's obs, else use original obs
        "use_rm_reward": True,  # if True use rm's reward, else use original reward
    }

    env.configure(config)

    obs, info = env.reset()
    if Train:
        # 建立模型
        model = DQN('MlpPolicy', env,
                    policy_kwargs=dict(net_arch=[256, 256]),
                    learning_rate=5e-4,
                    buffer_size=120000,
                    learning_starts=1600,
                    batch_size=256,
                    gamma=0.8,
                    train_freq=1,
                    gradient_steps=1,
                    target_update_interval=400,
                    verbose=1,
                    tensorboard_log=log_path)

        # tensorboard --logdir=

        model.learn(total_timesteps=int(1e3))
        model.save(model_path)
        del model

    # Load the model to observe the training effect, and calculate the collision rate and average speed
    model = DQN.load(model_name, env=env)

    act_list = ['LANE_LEFT', 'IDLE', 'LANE_RIGHT', 'FASTER', 'SLOWER']

    collision_rate = 0
    col_time = 0
    epi_time = int(1e1)

    sp_time = 0
    sp_all = 0
    sp_ave = 0

    time_test_start = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime())

    for i in range(epi_time):
        print("cur_episode  " + str(i) + "     collision happened  " + str(col_time))
        done = truncated = False
        obs, info = env.reset()

        while (not done) and (not truncated):
            # Predict
            action, _states = model.predict(obs, deterministic=True)
            # Get reward
            obs, reward, done, truncated, info = env.step((action.tolist()))
            # print(obs)
            # Render
            env.render()

            if not info['crashed']:
                sp_all += info['speed']
                sp_time += 1

            if info['crashed']:
                col_time = col_time + 1
                if save_picture_sig:
                    plt.imshow(env.render(mode="rgb_array"))
                    title = act_list[action]
                    plt.title(title, size=20, loc='center')
                    dir_name = log_path + str(time_test_start) + "\\"
                    if not os.path.isdir(dir_name):
                        os.makedirs(dir_name)
                    fig_name = dir_name + "col" + str(col_time) + ".png"
                    plt.savefig(fig_name, dpi=100, bbox_inches='tight')
                    plt.close()
    env.close()
    del model
    del env


    time_test_end = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime())

    collision_rate = col_time / epi_time
    print("collision_rate")
    print(collision_rate)

    sp_ave = sp_all / sp_time
    print("average_speed")
    print(sp_ave)

    data = pd.DataFrame([[str(time_test_start), str(time_test_end), epi_time, collision_rate, sp_ave]], columns=['time_test_start','time_test_end','test_episode_num', 'collision_rate', 'average_speed'])
    file_name = log_path + 'data_log_col_speed.csv'
    if os.path.isfile(file_name):
        df_existing = pd.read_csv(file_name)

        df_combined = pd.concat([df_existing, data], axis=0, ignore_index=True)

        df_combined.to_csv(file_name, index=False)
    else:
        data.to_csv(file_name, index=False)
