import gymnasium as gym
import torch as th
from stable_baselines3 import PPO
from torch.distributions import Categorical
import torch
import torch.nn as nn
import numpy as np
from torch.nn import functional as F
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor
from stable_baselines3.common.vec_env import SubprocVecEnv
import highway_env

import matplotlib.pyplot as plt
import os
import time
import pandas as pd


version = "test"
log_path = "F:\\RMRL_Project\\RMRL1\\date\\highway\\sb3_pp0\\highway_sb3_ppo\\"

if not os.path.isdir(log_path):
    os.makedirs(log_path)

config = {
    "observation": {
        "type": "Kinematics",
        "features": ["x", "y", "vx", "vy", "heading"],
        "features_range": {
            "x": [-100, 100],
            "y": [-6, 6],
            "vx": [-30, 30],
            "vy": [-30, 30],
            "heading": [-3.15 / 2, 3.15 / 2]
        },
        "absolute": False,
        "normalize": True,
        "see_behind": False,
        "order": "sorted",
    },
    "action": {
        "type": "DiscreteMetaAction",
    },
    "lanes_count": 2,
    "vehicles_count": 10,
    "policy_frequency": 8,
    "simulation_frequency": 8,

    "use_rm_obs": True,  # if True use rm's obs, else use original obs
    "use_rm_reward": True,  # if True use rm's reward, else use original reward
}

env_kwargs = {
    'id': 'highway-fast-v0',
    'config': config
}

def make_configure_env(**kwargs):
    env = gym.make(kwargs["id"])
    env.configure(kwargs["config"])
    env.reset()
    return env


if __name__ == '__main__':
    for train_test_time in range(0, 6):
        model_path = log_path + "model_" + str(version)  + str(train_test_time)
        model_name = model_path + ".zip"

        # Train = False
        Train = True

        # save_picture_sig = False   # whether save collision picture
        save_picture_sig = True

        if Train:
            n_cpu = 16
            batch_size = 512

            env = make_vec_env(make_configure_env, n_envs=n_cpu, vec_env_cls=SubprocVecEnv, env_kwargs=env_kwargs)

            model = PPO("MlpPolicy",
                        env,
                        policy_kwargs=dict(net_arch=[dict(pi=[256, 256], vf=[256, 256])]),
                        n_steps=batch_size * 12 // n_cpu,
                        batch_size=batch_size,
                        n_epochs=10,
                        learning_rate=5e-4,
                        gamma=0.8,
                        verbose=2,
                        _init_setup_model=True,
                        tensorboard_log=log_path)

            # Train the agent
            model.learn(total_timesteps=int(6e5))
            # Save the agent
            model.save(model_path)
            del model

        # Load the model to observe the training effect, and calculate the collision rate and average speed
        model = PPO.load(model_name)
        env = make_configure_env(**env_kwargs)

        act_list = ['LANE_LEFT', 'IDLE', 'LANE_RIGHT', 'FASTER', 'SLOWER']

        collision_rate = 0
        col_time = 0
        epi_time = int(1e3)

        sp_time = 0
        sp_all = 0
        sp_ave = 0

        time_test_start = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime())

        for i in range(epi_time):
            print("cur_episode  " + str(i) + "     collision happened  " + str(col_time))
            done = truncated = False
            obs, info = env.reset()

            while not (done or truncated):
                # Predict
                action, _states = model.predict(obs, deterministic=True)
                # Get reward
                obs, reward, done, truncated, info = env.step((action.tolist()))
                # print(obs)
                # Render
                env.render()

                if not info['crashed']:
                    sp_all += info['speed']
                    sp_time += 1

                if info['crashed']:
                    col_time = col_time + 1
                    if save_picture_sig:
                        plt.imshow(env.render())
                        title = act_list[action]
                        plt.title(title, size=20, loc='center')
                        dir_name = log_path + str(time_test_start) + "\\"
                        if not os.path.isdir(dir_name):
                            os.makedirs(dir_name)
                        fig_name = dir_name + "col" + str(col_time) + ".png"
                        plt.savefig(fig_name, dpi=100, bbox_inches='tight')
                        plt.close()

        del model
        del env

        time_test_end = time.strftime("%Y-%m-%d-%H_%M_%S", time.localtime())

        collision_rate = col_time / epi_time
        print("collision_rate")
        print(collision_rate)

        sp_ave = sp_all / sp_time
        print("average_speed")
        print(sp_ave)

        data = pd.DataFrame([[str(time_test_start), str(time_test_end), epi_time, collision_rate, sp_ave]],
                            columns=['time_test_start', 'time_test_end', 'test_episode_num', 'collision_rate', 'average_speed'])
        file_name = log_path + 'data_log_col_speed.csv'
        if os.path.isfile(file_name):
            df_existing = pd.read_csv(file_name)

            df_combined = pd.concat([df_existing, data], axis=0, ignore_index=True)

            df_combined.to_csv(file_name, index=False)
        else:
            data.to_csv(file_name, index=False)
